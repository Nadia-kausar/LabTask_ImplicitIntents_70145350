
package com.example.uolhelpdesk;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class RequestActivity extends AppCompatActivity {

    @SuppressLint({"SetTextI18n", "HardcodedText"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);

        TextView tvGreeting = findViewById(R.id.tvGreeting);
        EditText etPhone = findViewById(R.id.etPhone);
        EditText etLink = findViewById(R.id.etLink);
        Button btnCallNumber = findViewById(R.id.btnCallNumber);
        Button btnOpenLink = findViewById(R.id.btnOpenLink);

        String name = getIntent().getStringExtra(MainActivity.EXTRA_NAME);

        if (name == null || name.trim().isEmpty()) {
            name = "Student";
        }

        tvGreeting.setText(
                "Hello, " + name + "! How can we help you today?"
        );

        btnCallNumber.setOnClickListener(v -> {
            String number = etPhone.getText().toString().trim();

            if (!number.matches("03[0-9]{9}")) {
                etPhone.setError("Enter 11 digits starting with 03");
                etPhone.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + number)
            );

            IntentHelper.openIntent(this, intent);
        });

        btnOpenLink.setOnClickListener(v -> {
            String link = etLink.getText().toString().trim();

            if (link.isEmpty()) {
                etLink.setError("Please enter a link");
                etLink.requestFocus();
                return;
            }

            String lowerLink = link.toLowerCase(Locale.ROOT);

            if (!lowerLink.startsWith("http://")
                    && !lowerLink.startsWith("https://")) {
                link = "https://" + link;
            }

            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(link)
            );

            IntentHelper.openIntent(this, intent);
        });
    }
}
