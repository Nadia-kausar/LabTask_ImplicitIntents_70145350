
package com.example.uolhelpdesk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NAME =
            "com.example.uolhelpdesk.EXTRA_NAME";

    EditText etName;
    Button btnWebsite, btnCall, btnMap, btnRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        btnWebsite = findViewById(R.id.btnWebsite);
        btnCall = findViewById(R.id.btnCall);
        btnMap = findViewById(R.id.btnMap);
        btnRequest = findViewById(R.id.btnRequest);

        // Visit Website
        btnWebsite.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.uol.edu.pk")
            );
            IntentHelper.openIntent(this, intent);
        });

        // Call Help Desk
        btnCall.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:04212345678")
            );
            IntentHelper.openIntent(this, intent);
        });

        // Find Campus
        btnMap.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("geo:0,0?q=University+of+Lahore")
            );
            IntentHelper.openIntent(this, intent);
        });

        // Send a Request
        btnRequest.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();

            if (name.isEmpty()) {
                etName.setError("Please enter your name");
                etName.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    MainActivity.this,
                    RequestActivity.class
            );

            intent.putExtra(EXTRA_NAME, name);
            startActivity(intent);
        });
    }
}
